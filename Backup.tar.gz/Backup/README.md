
- 1 - Install the Git community plugin
- 2 - CTRL + P `Clone an existing remote repo`
- 3 - put: `https://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@github.com/martinjrrr/obsidian-git-sync`
- 4 - type in the folder you want the repository to be cloned into

https://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@github.com/martinjrrr/Linux.dots
